/*
 * MenuScene.h
 *
 *  Created on: 20.09.2014
 *      Author: user
 */

#ifndef MENUSCENE_H_
#define MENUSCENE_H_

#include "Scene.h"
#include "Texture.h"

#include <string>
#include <vector>

namespace game {

class MenuScene : public Scene {
public:
    MenuScene(unsigned currentScenario = 0);
    virtual ~MenuScene();

    virtual void init();
    virtual void tick();
    virtual void draw();
    virtual void event(SDL_Event* event);

private:
    bool isLevelVisible(const Level* level);
    bool isLevelPlayable(const Level* level);
    bool renderDescription(const Level* level, const Rect* rect, const std::string& head, const std::string& body);
    Rect getLevelPosition(const Level* level);

    unsigned scrollOffset;
    unsigned currentScenario;
    unsigned currentMaxLevelY;
    Texture textOptions;
    Texture textExit;
    Texture textDescriptionHead;
    Texture textDescriptionBody;
    const Rect* descriptionRect;
};

} /* namespace game */

#endif /* MENUSCENE_H_ */
