/*
 * Gui.h
 *
 *  Created on: 21.09.2014
 *      Author: user
 */

#ifndef GUI_H_
#define GUI_H_

#include "Constants.h"

namespace game {

class Level;
class Texture;

class Gui {
public:
    Gui();
    ~Gui();

    void drawBegin() const;
    void drawEnd() const;

    static bool init();
    static int showMessageBox(const char* title, const char* message);

    static void drawButtonHalf(int x, int y, int id);
    static void drawButtonFull(int x, int y, int id);
    static void drawButtonDouble(int x, int y, int id);
    static void drawPart(int x, int y, int animation, int id, int rotation = 0);
    static void drawBand(int x, int y, const char *band);
    static void drawBand(int x, int y, int id);
    static void drawColor(int r, int g, int b, int a);
    static void drawLine(int x1, int y1, int x2, int y2);
    static void drawLevel(Level *level, int animationCycle, int sourceCycle = 0, int sinkCycle = 0);
    static void drawObject(int x, int y, int id, int animation);
    static void drawTexture(const Texture& texture, int x, int y);
    static void drawTextureCentered(const Texture& texture, const Rect& rect);
    static void renderText(Texture& result, const char *text, unsigned wrapLength = 800);
    static void setClipRect(const SDL_Rect* rect);
    static SDL_Texture *createLineTexture();
private:
    static TTF_Font *font;
    static SDL_Window *window;
    static SDL_Renderer *renderer;
    static SDL_Texture *buttons_half;
    static SDL_Texture *buttons_full;
    static SDL_Texture *buttons_double;
    static SDL_Texture *parts;
    static SDL_Texture *testobjects;
    static SDL_Texture *band;
    static SDL_Texture *version;
    static SDL_Texture *line;
};

} /* namespace game */

#endif /* GUI_H_ */
