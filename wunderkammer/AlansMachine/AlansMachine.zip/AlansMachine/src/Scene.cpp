/*
 * Scene.cpp
 *
 *  Created on: 23.09.2014
 *      Author: user
 */

#include "Scene.h"

#include <SDL.h>

namespace game {

const Point INVALID_POINT = {-1, -1};

Scene::Scene() :
        mouse(INVALID_POINT), mouseDown(INVALID_POINT), mouseUp(INVALID_POINT), key() {
    for (size_t i = 0; i < sizeof(key); ++i) {
        key[i] = false;
    }
}

Scene::~Scene() {
}

void Scene::event(SDL_Event* event) {
    switch (event->type) {
    case SDL_MOUSEMOTION:
        mouse.x = event->motion.x;
        mouse.y = event->motion.y;
        break;

    case SDL_MOUSEBUTTONDOWN:
        if (event->button.button != 1) {
            return;
        }
        mouseDown.x = event->button.x;
        mouseDown.y = event->button.y;
        break;

    case SDL_MOUSEBUTTONUP:
        if (event->button.button != 1) {
            return;
        }
        mouseUp.x = event->button.x;
        mouseUp.y = event->button.y;
        break;

    case SDL_KEYDOWN:
        key[event->key.keysym.scancode] = true;
        break;

    case SDL_KEYUP:
        key[event->key.keysym.scancode] = false;
        break;

    default:
        return;
    }
}

bool Scene::isClick(const Rect& rect) {
    return rect.contains(mouseDown) && rect.contains(mouseUp);
}

} /* namespace game */
