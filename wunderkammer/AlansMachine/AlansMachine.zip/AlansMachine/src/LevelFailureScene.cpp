/*
 * LevelFailureScene.cpp
 *
 *  Created on: 21.09.2014
 *      Author: user
 */

#include "Audio.h"
#include "Gui.h"
#include "Level.h"
#include "LevelFailureScene.h"

#include <SDL.h>

using namespace std;

namespace game {

LevelFailureScene::LevelFailureScene(const unsigned& scenarioId, const unsigned& levelId, const TestStatus& testStatus) :
        LevelScene(scenarioId, levelId), testStatus(testStatus), textFailure(), textRetry(), textMenu(), textObjectiveHead(), textObjectiveBody(), textInput(), textExpected(), textOutput(), textAcceptExpected(), textAcceptOutput() {
}

LevelFailureScene::~LevelFailureScene() {
}

void LevelFailureScene::init() {
    Gui::renderText(textFailure, "Failure!");
    Gui::renderText(textRetry, "Retry");
    Gui::renderText(textMenu, "Menu");
    Gui::renderText(textObjectiveHead, "Objective:");
    Gui::renderText(textObjectiveBody, currentLevel->objective.c_str(), 180);
    Gui::renderText(textInput, "Input:");
    Gui::renderText(textExpected, "Expected:");
    Gui::renderText(textOutput, "Your output:");
    if (currentLevel->tests[testStatus.testId].accept) {
        Gui::renderText(textAcceptExpected, "Accept: Yes");
    } else {
        Gui::renderText(textAcceptExpected, "Accept: No");
    }
    if (testStatus.status == 1) {
        Gui::renderText(textAcceptOutput, "Accept: Yes");
    } else {
        Gui::renderText(textAcceptOutput, "Accept: No");
    }
}

void LevelFailureScene::tick() {
}

void LevelFailureScene::draw() {
    Gui::drawTextureCentered(textFailure, HEADER_AREA);
    Gui::drawButtonDouble(600, 9 * BUTTON_SIZE_FULL, 0);
    Gui::drawButtonDouble(600, 10 * BUTTON_SIZE_FULL, 1);
    Gui::drawButtonDouble(600, 11 * BUTTON_SIZE_FULL, 2);
    Gui::drawTextureCentered(textMenu, BUTTON_RIGHT2);
    Gui::drawTextureCentered(textRetry, BUTTON_RIGHT3);

    for (int x = 0; x < 3; ++x) {
        Gui::drawButtonDouble(x * 200, 1 * BUTTON_SIZE_FULL, 5);
        for (int y = 2; y < 11; ++y) {
            Gui::drawButtonDouble(x * 200, y * BUTTON_SIZE_FULL, 7);
        }
        Gui::drawButtonDouble(x * 200, 550, 6);
    }

    Gui::drawButtonDouble(600, 1 * BUTTON_SIZE_FULL, 5);
    for (int i = 2; i < 8; ++i) {
        Gui::drawButtonDouble(600, BUTTON_SIZE_FULL * i, 7);
    }
    Gui::drawButtonDouble(600, 8 * BUTTON_SIZE_FULL, 6);

    Gui::drawTexture(textInput, 10, 60);
    Gui::drawTexture(textExpected, 210, 60);
    Gui::drawTexture(textOutput, 410, 60);
    Gui::drawTexture(textObjectiveHead, 610, 60);
    Gui::drawTexture(textObjectiveBody, 610, 100);
    Gui::drawTexture(textAcceptExpected, 210, 550);
    Gui::drawTexture(textAcceptOutput, 410, 550);

    Gui::drawBand(25, 100, currentLevel->tests[testStatus.testId].input.c_str());
    Gui::drawBand(225, 100, currentLevel->tests[testStatus.testId].output.c_str());
    Gui::drawBand(425, 100, testStatus.band.empty() ? "Z" : testStatus.band.c_str());
}

void LevelFailureScene::event(SDL_Event* event) {
    Scene::event(event);

    switch (event->type) {
    case SDL_MOUSEBUTTONUP:
        /* right button pressed? */
        if (isClick(BUTTON_RIGHT2)) {
            Audio::playEffect(0);
            goMenu();
            return;
        }

        if (isClick(BUTTON_RIGHT3)) {
            Audio::playEffect(0);
            goEdit();
            return;
        }
        break;

    default:
        break;
    }
}

} /* namespace game */
