/*
 * Level.cpp
 *
 *  Created on: 22.09.2014
 *      Author: user
 */

#include "Level.h"

#include <SDL.h>

using namespace std;

namespace game {

static bool equalsMod4(const int a, const int b) {
    return (a + 4) % 4 == (b + 4) % 4;
}

const Part Part::INVALID = Part("INVALID", -1, 0);
const Part Part::SOURCE = Part("source", 0, 0);
const Part Part::SINK = Part("sink", 1, 0);
const Part Part::BELT = Part("belt", 2, 0);
const Part Part::CROSS_L = Part("cross_l", 3, 0);
const Part Part::CROSS_R = Part("cross_r", 4, 0);
const Part Part::BRANCH_RB = Part("branch_rb", 5, 0);
const Part Part::BRANCH_BR = Part("branch_br", 6, 0);
const Part Part::BRANCH_GY = Part("branch_gy", 7, 0);
const Part Part::BRANCH_YG = Part("branch_yg", 8, 0);
const Part Part::PRINTER_R = Part("printer_r", 9, 0);
const Part Part::PRINTER_B = Part("printer_b", 10, 0);
const Part Part::PRINTER_G = Part("printer_g", 11, 0);
const Part Part::PRINTER_Y = Part("printer_y", 12, 0);

Part ALLPARTS[] = {Part::SOURCE, Part::SINK, Part::BELT, Part::CROSS_L, Part::CROSS_R, Part::BRANCH_RB, Part::BRANCH_BR, Part::BRANCH_GY, Part::BRANCH_YG, Part::PRINTER_R, Part::PRINTER_B, Part::PRINTER_G, Part::PRINTER_Y};

Part::Part(const string& name, const int& partId, const int& rotation) :
        name(name), partId(partId), rotation(rotation) {
}

Part::~Part() {
}

bool Part::operator!() const {
    return partId == INVALID.partId;
}

bool Part::operator==(const Part& other) const {
    return partId == other.partId;
}

bool Part::operator!=(const Part& other) const {
    return partId != other.partId;
}

Part Part::getPartById(const int& partId, const int& rotation) {
    for(size_t i = 0; i < sizeof(ALLPARTS); ++i) {
        if(ALLPARTS[i].partId == partId) {
            return Part(ALLPARTS[i].name, partId, rotation);
        }
    }
    return Part::INVALID;
}

Part Part::getPartByName(const std::string& name, const int& rotation) {
    for(size_t i = 0; i < sizeof(ALLPARTS); ++i) {
        if(ALLPARTS[i].name == name) {
            return Part(name, ALLPARTS[i].partId, rotation);
        }
    }
    return Part::INVALID;
}

Tile::Tile() : x(-1), y(-1), partId(Part::INVALID.partId), rotation(Part::INVALID.rotation) {
}

Tile::Tile(const int& x, const int& y, const int& partId, const int& rotation) :
        x(x), y(y), partId(partId), rotation(rotation) {
}

Tile::~Tile() {
}

bool TestStatus::isCorrect(const Test& test) {
    if ((test.accept && status == 2) || (!test.accept && status == 1)) {
        return false;
    }

    if (test.output == "A") {
        return true;
    }

    if (test.output == "Z" && band.empty()) {
        return true;
    }

    return test.output == band;
}

void TestStatus::move() {
    switch (direction) {
    case 3:
        position.x -= 1;
        break;

    case 2:
        position.y += 1;
        break;

    case 1:
        position.x += 1;
        break;

    case 0:
        position.y -= 1;
        break;

    default:
        break;
    }
}

void TestStatus::execute(const Part& part) {
    switch (part.partId) {
    case 0: /* source */
    case 1: /* sink */
        break;

    case 2: /* conveyor belt */
        direction = (part.rotation + DIRECTION_DOWN) % 4;
        break;

    case 3: /* conveyor cross left */
        if (equalsMod4(direction, part.rotation) || equalsMod4(direction, part.rotation + 2)) {
            direction = (part.rotation + DIRECTION_DOWN) % 4;
        } else {
            direction = (part.rotation + DIRECTION_LEFT) % 4;
        }
        break;

    case 4: /* conveyor cross right */
        if (equalsMod4(direction, part.rotation) || equalsMod4(direction, part.rotation + 2)) {
            direction = (part.rotation + DIRECTION_DOWN) % 4;
        } else {
            direction = (part.rotation + DIRECTION_RIGHT) % 4;
        }
        break;

    case 5: /* switch rb */
        if (band[0] == 'R') {
            band.erase(0, 1);
            direction = (part.rotation + DIRECTION_LEFT) % 4;
        } else if (band[0] == 'B') {
            band.erase(0, 1);
            direction = (part.rotation + DIRECTION_RIGHT) % 4;
        } else {
            direction = (part.rotation + DIRECTION_DOWN) % 4;
        }
        break;

    case 6: /* switch br */
        if (band[0] == 'R') {
            band.erase(0, 1);
            direction = (part.rotation + DIRECTION_LEFT) % 4;
        } else if (band[0] == 'B') {
            band.erase(0, 1);
            direction = (part.rotation + DIRECTION_RIGHT) % 4;
        } else {
            direction = (part.rotation + DIRECTION_DOWN) % 4;
        }
        break;

    case 7: /* switch gy */
        if (band[0] == 'G') {
            band.erase(0, 1);
            direction = (part.rotation + DIRECTION_LEFT) % 4;
        } else if (band[0] == 'Y') {
            band.erase(0, 1);
            direction = (part.rotation + DIRECTION_RIGHT) % 4;
        } else {
            band = (part.rotation + DIRECTION_DOWN) % 4;
        }
        break;

    case 8: /* switch yg */
        if (band[0] == 'G') {
            band.erase(0, 1);
            direction = (part.rotation + DIRECTION_LEFT) % 4;
        } else if (band[0] == 'Y') {
            band.erase(0, 1);
            direction = (part.rotation + DIRECTION_RIGHT) % 4;
        } else {
            band = (part.rotation + DIRECTION_DOWN) % 4;
        }
        break;

    case 9: /* printer r */
        band.push_back('R');
        direction = (part.rotation + DIRECTION_DOWN) % 4;
        break;

    case 10: /* printer b */
        band.push_back('B');
        direction = (part.rotation + DIRECTION_DOWN) % 4;
        break;

    case 11: /* printer g */
        band.push_back('G');
        direction = (part.rotation + DIRECTION_DOWN) % 4;
        break;

    case 12: /* printer y */
        band.push_back('Y');
        direction = (part.rotation + DIRECTION_DOWN) % 4;
        break;

    default:
        SDL_LogError(SDL_LOG_CATEGORY_APPLICATION, "Can not execute part with id %i on tile %i,%i", part.partId, position.x, position.y);
        break;
    }

}

Part Level::getPart(const int x, const int y) const {
    for (vector<Tile>::const_iterator it = tiles.begin(); it != tiles.end(); ++it) {
        if (it->x == x && it->y == y) {
            return Part::getPartById(it->partId, it->rotation);
        }
    }

    return Part::INVALID;
}

void Level::setPart(const int x, const int y, const Part& part) {
    if (x < 0 || y < 0 || (unsigned) x >= size || (unsigned) y >= size) {
        /* not in the field */
        return;
    }

    if ((unsigned) y == size / 2 && (x == 0 || (unsigned) x == size - 1)) {
        /* source or sink */
        return;
    }

    for (vector<Tile>::iterator it = tiles.begin(); it != tiles.end(); ++it) {
        if (it->x == x && it->y == y) {
            it->partId = part.partId;
            it->rotation = part.rotation;
            return;
        }
    }
    Tile tile(x, y, part.partId, part.rotation);
    tiles.push_back(tile);
}

Part Level::delPart(const int x, const int y) {
    for (vector<Tile>::iterator it = tiles.begin(); it != tiles.end(); ++it) {
        if (it->x == x && it->y == y) {
            Part part = Part::getPartById(it->partId, it->rotation);
            tiles.erase(it);
            return part;
        }
    }
    return Part::INVALID;
}

} /* namespace game */
