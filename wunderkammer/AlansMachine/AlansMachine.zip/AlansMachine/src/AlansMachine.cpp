//============================================================================
// Name        : AlansMachine.cpp
// Author      : Tim Wiederhake
// Version     :
// Copyright   : All rights reserved
//============================================================================

#include "Game.h"

int main(int argc, char *argv[]) {
    game::Game game(argc, argv);

    while (game) {
        game.event();

        game.tick();

        game.draw();

        game.stat();
    }

    return 0;
}
