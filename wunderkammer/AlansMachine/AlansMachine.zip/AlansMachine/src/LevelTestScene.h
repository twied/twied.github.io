/*
 * LevelTestScene.h
 *
 *  Created on: 21.09.2014
 *      Author: user
 */

#ifndef LEVELTESTSCENE_H_
#define LEVELTESTSCENE_H_

#include "LevelScene.h"
#include "Texture.h"

#include <string>

namespace game {

class Level;

class LevelTestScene : public LevelScene {
public:
    LevelTestScene(const unsigned& scenarioId, const unsigned& levelId);
    virtual ~LevelTestScene();

    virtual void init();
    virtual void tick();
    virtual void draw();
    virtual void event(SDL_Event* event);
private:
    bool nextTest();
    unsigned ticksPerPhysicsStep();
    void runPart();
    bool drawSpecial();
    void drawTestObject(int animation);

    unsigned animationCycle;
    unsigned specialAnimation;
    unsigned specialAnimationCycle;
    unsigned physicsCycle;
    int currentSpeed;
    TestStatus currentTestStatus;

    Texture textBand;
    Texture textBack;
    Texture textMenu;
    Texture textFaster;
    Texture textSlower;
    Texture textPaused;
};

} /* namespace game */

#endif /* LEVELTESTSCENE_H_ */
