/*
 * LevelSuccessScene.cpp
 *
 *  Created on: 21.09.2014
 *      Author: user
 */

#include "Audio.h"
#include "Data.h"
#include "Game.h"
#include "Gui.h"
#include "LevelEditScene.h"
#include "LevelSuccessScene.h"

#include <SDL.h>

#include <sstream>
#include <string>

using namespace std;

namespace game {

template<typename value_type> string toString(const value_type& value) {
    stringstream stream;
    stream << value;
    return stream.str();
}

LevelSuccessScene::LevelSuccessScene(const unsigned& scenarioId, const unsigned& levelId) :
        LevelScene(scenarioId, levelId) {
}

LevelSuccessScene::~LevelSuccessScene() {
}

void LevelSuccessScene::init() {
    Gui::renderText(textSuccess, "Success!");
    Gui::renderText(textRerun, "Rerun");
    Gui::renderText(textMenu, "Next level");
    Gui::renderText(textRunThis, "This run:");
    Gui::renderText(textRunBest, "Previous best run:");
    Gui::renderText(textParts, "Parts used:");
    Gui::renderText(textObjectiveHead, "Objective: ");
    Gui::renderText(textObjectiveBody, currentLevel->objective.c_str(), 180);

    unsigned amountPartsTotal = 0;
    for(size_t i = 0; i < currentLevel->parts.size(); ++i) {
        int amount = 0;
        for(vector<Tile>::const_iterator it = currentLevel->tiles.begin(); it != currentLevel->tiles.end(); ++it) {
            if(it->partId == currentLevel->parts[i].partId) {
                amount += 1;
            }
        }
        amountPartsTotal += amount;
        Gui::renderText(textPartAmount[i], toString(amount).c_str());
    }

    unsigned amountTimeUnitsTotal = 0;
    unsigned amountTimeUnitsBest = (unsigned) -1;
    unsigned amountTimeUnitsWorst = 0;

    for(size_t i = 0; i < currentLevel->tests.size(); ++i) {
        unsigned steps = currentLevel->tests[i].steps;
        amountTimeUnitsTotal += steps;
        if(amountTimeUnitsBest > steps) {
            amountTimeUnitsBest = steps;
        }
        if(amountTimeUnitsWorst < steps) {
            amountTimeUnitsWorst = steps;
        }
    }

    if(!currentLevel->totalSteps) {
        currentLevel->totalSteps = amountTimeUnitsTotal;
        currentLevel->totalStepsBest = amountTimeUnitsBest;
        currentLevel->totalStepsWorst = amountTimeUnitsWorst;
        currentLevel->totalPartsBest = amountPartsTotal;
        Data::saveLevelDynamicData(scenarioId, levelId);
    }

    Gui::renderText(textCyclesTotal[0], "Total time units:", 180);
    Gui::renderText(textCyclesTotal[1], toString(amountTimeUnitsTotal).c_str(), 180);
    Gui::renderText(textCyclesTotal[2], toString(currentLevel->totalSteps).c_str(), 180);

    Gui::renderText(textCyclesAverage[0], "Average time units per test:", 180);
    Gui::renderText(textCyclesAverage[1], toString((double)amountTimeUnitsTotal / currentLevel->tests.size()).c_str(), 180);
    Gui::renderText(textCyclesAverage[2], toString((double)currentLevel->totalSteps / currentLevel->tests.size()).c_str(), 180);

    Gui::renderText(textCyclesBest[0], "Least time units per test:", 180);
    Gui::renderText(textCyclesBest[1], toString(amountTimeUnitsBest).c_str(), 180);
    Gui::renderText(textCyclesBest[2], toString(currentLevel->totalStepsBest).c_str(), 180);

    Gui::renderText(textCyclesWorst[0], "Most time units per test:", 180);
    Gui::renderText(textCyclesWorst[1], toString(amountTimeUnitsWorst).c_str(), 180);
    Gui::renderText(textCyclesWorst[2], toString(currentLevel->totalStepsWorst).c_str(), 180);

    Gui::renderText(textPartsUsed[0], "Total parts used:", 180);
    Gui::renderText(textPartsUsed[1], toString(amountPartsTotal).c_str(), 180);
    Gui::renderText(textPartsUsed[2], toString(currentLevel->totalPartsBest).c_str(), 180);

    if(!currentLevel->totalSteps || amountTimeUnitsTotal < currentLevel->totalSteps) {
        currentLevel->totalSteps = amountTimeUnitsTotal;
        currentLevel->totalStepsBest = amountTimeUnitsBest;
        currentLevel->totalStepsWorst = amountTimeUnitsWorst;
        Data::saveLevelDynamicData(scenarioId, levelId);
    }

    if(!currentLevel->totalPartsBest || amountPartsTotal < currentLevel->totalPartsBest) {
        currentLevel->totalPartsBest = amountPartsTotal;
        Data::saveLevelDynamicData(scenarioId, levelId);
    }
}

void LevelSuccessScene::tick() {
}

void LevelSuccessScene::draw() {
    Gui::drawTextureCentered(textSuccess, HEADER_AREA);
    Gui::drawButtonDouble(600, 9 * BUTTON_SIZE_FULL, 0);
    Gui::drawButtonDouble(600, 10 * BUTTON_SIZE_FULL, 1);
    Gui::drawButtonDouble(600, 11 * BUTTON_SIZE_FULL, 2);
    Gui::drawTextureCentered(textRerun, BUTTON_RIGHT2);
    Gui::drawTextureCentered(textMenu, BUTTON_RIGHT3);

    for (int x = 0; x < 3; ++x) {
        Gui::drawButtonDouble(x * 200, 1 * BUTTON_SIZE_FULL, 5);
        for (int y = 2; y < 11; ++y) {
            Gui::drawButtonDouble(x * 200, y * BUTTON_SIZE_FULL, 7);
        }
        Gui::drawButtonDouble(x * 200, 550, 6);
    }

    Gui::drawButtonDouble(600, 1 * BUTTON_SIZE_FULL, 5);
    for (int i = 2; i < 8; ++i) {
        Gui::drawButtonDouble(600, BUTTON_SIZE_FULL * i, 7);
    }
    Gui::drawButtonDouble(600, 8 * BUTTON_SIZE_FULL, 6);

    Gui::drawTexture(textRunThis, 10, 60);
    Gui::drawTexture(textRunBest, 210, 60);
    Gui::drawTexture(textParts, 410, 60);
    Gui::drawTexture(textObjectiveHead, 610, 60);
    Gui::drawTexture(textObjectiveBody, 610, 100);

    for(size_t i = 0; i < currentLevel->parts.size(); ++i) {
        Gui::drawPart(405 + 100 * (i % 2), 90 + 60 * (i / 2), 0, currentLevel->parts[i].partId, 0);
        Gui::drawTexture(textPartAmount[i], 450 + 100 * (i % 2), 115 + 60 * (i / 2));
    }

    for(int i = 0; i < 2; ++i) {
        Gui::drawTexture(textCyclesTotal[0], 10 + i * BUTTON_SIZE_DOUBLE, 150);
        Gui::drawTexture(textCyclesAverage[0], 10 + i * BUTTON_SIZE_DOUBLE, 250);
        Gui::drawTexture(textCyclesBest[0], 10 + i * BUTTON_SIZE_DOUBLE, 350);
        Gui::drawTexture(textCyclesWorst[0], 10 + i * BUTTON_SIZE_DOUBLE, 450);
        Gui::drawTexture(textPartsUsed[0], 10 + i * BUTTON_SIZE_DOUBLE, 550);
    }

    Gui::drawTexture(textCyclesTotal[1], 20, 170);
    Gui::drawTexture(textCyclesAverage[1], 20, 290);
    Gui::drawTexture(textCyclesBest[1], 20, 390);
    Gui::drawTexture(textCyclesWorst[1], 20, 490);
    Gui::drawTexture(textPartsUsed[1], 20, 570);

    Gui::drawTexture(textCyclesTotal[2], 220, 170);
    Gui::drawTexture(textCyclesAverage[2], 220, 290);
    Gui::drawTexture(textCyclesBest[2], 220, 390);
    Gui::drawTexture(textCyclesWorst[2], 220, 490);
    Gui::drawTexture(textPartsUsed[2], 220, 570);
}

void LevelSuccessScene::event(SDL_Event* event) {
    Scene::event(event);

    switch (event->type) {
    case SDL_MOUSEBUTTONUP:
        /* right button pressed? */
        if (isClick(BUTTON_RIGHT2)) {
            Audio::playEffect(0);
            goEdit();
            return;
        }

        if (isClick(BUTTON_RIGHT3)) {
            Audio::playEffect(0);
            goMenu();
            return;
        }
        break;

    default:
        break;
    }
}

} /* namespace game */
