/*
 * Scenario.cpp
 *
 *  Created on: 22.09.2014
 *      Author: user
 */

#include "Level.h"
#include "Scenario.h"

using namespace std;

namespace game {

Scenario::Scenario() :
        id(), levelList(vector<Level *>()) {
}

Scenario::~Scenario() {
    for (size_t i = 0; i < levelList.size(); ++i) {
        delete levelList[i];
    }
}

} /* namespace game */
