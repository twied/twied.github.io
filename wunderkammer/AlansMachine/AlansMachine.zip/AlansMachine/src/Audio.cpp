/*
 * Audio.cpp
 *
 *  Created on: 23.09.2014
 *      Author: user
 */

#include "Audio.h"
#include "Data.h"
#include "Gui.h"

#include <SDL.h>
#include <SDL_mixer.h>

namespace game {

Mix_Chunk* Audio::clickGood = NULL;
Mix_Chunk* Audio::clickBad = NULL;
Mix_Music* Audio::music = NULL;

Audio::Audio() {
}

Audio::~Audio() {
    if (clickGood) {
        Mix_FreeChunk(clickGood);
    }

    if (clickBad) {
        Mix_FreeChunk(clickBad);
    }

    if (music) {
        Mix_HaltMusic();
        Mix_FreeMusic(music);
    }

    Mix_Quit();
}

bool Audio::init() {
    if (Mix_Init(MIX_INIT_MP3) == 0) {
        Gui::showMessageBox("Mix_Init failed", Mix_GetError());
        return false;
    }

    if (Mix_OpenAudio(MIX_DEFAULT_FREQUENCY, MIX_DEFAULT_FORMAT, 1, 4096)) {
        Gui::showMessageBox("Mix_OpenAudio failed", Mix_GetError());
        return false;
    }

    clickGood = Mix_LoadWAV("res/sound/click_good.wav");
    if (!clickGood) {
        Gui::showMessageBox("Mix_LoadWAV failed for click_good.wav",
        Mix_GetError());
        return false;
    }

    clickBad = Mix_LoadWAV("res/sound/click_bad.wav");
    if (!clickBad) {
        Gui::showMessageBox("Mix_LoadWAV failed for click_bad.wav",
        Mix_GetError());
        return false;
    }

    music = Mix_LoadMUS("res/sound/music.mp3");
    if (!music) {
        Gui::showMessageBox("Mix_LoadMUS failed for music.mp3", Mix_GetError());
        return false;
    }

    playMusic(Data::getSettings()->music);
    return true;
}

void Audio::playEffect(int effectId) {
    if (!Data::getSettings()->sound) {
        return;
    }

    switch (effectId) {
    case 0:
        Mix_PlayChannel(-1, clickGood, 0);
        return;

    case 1:
        Mix_PlayChannel(-1, clickBad, 0);
        return;

    default:
        return;
    }
}

void Audio::playMusic(bool enable) {
    if (enable) {
        if (!Mix_PlayingMusic()) {
            Mix_PlayMusic(music, -1);
        } else {
            Mix_ResumeMusic();
        }
    } else {
        Mix_PauseMusic();
    }
}
} /* namespace game */
