/*
 * Data.h
 *
 *  Created on: 21.09.2014
 *      Author: user
 */

#ifndef DATA_H_
#define DATA_H_

#include <vector>

namespace game {

class Level;
class Part;
class Scenario;

struct Settings {
    bool music;
    bool sound;

    Settings() :
            music(true), sound(true) {
    }
};

class Data {
public:
    Data();
    ~Data();

    bool init();
    static Level* getLevel(const unsigned& scenarioId, const unsigned& levelId);
    static Scenario* getScenario(const unsigned& scenarioId);

    static bool loadLevelDynamicData(const unsigned& scenarioId, const unsigned& levelId);
    static bool saveLevelDynamicData(const unsigned& scenarioId, const unsigned& levelId);

    static Settings* getSettings();
    static void saveSettings();
private:
    static Settings settings;
    static std::vector<Scenario*> scenarioList;
    static std::vector<Part*> partList;
};

} /* namespace game */

#endif /* DATA_H_ */
