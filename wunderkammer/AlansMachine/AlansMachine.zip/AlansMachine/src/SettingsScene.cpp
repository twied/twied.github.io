/*
 * SettingsScene.cpp
 *
 *  Created on: 23.09.2014
 *      Author: user
 */

#include "Audio.h"
#include "Data.h"
#include "Game.h"
#include "Gui.h"
#include "MenuScene.h"
#include "SettingsScene.h"

#include <SDL.h>

namespace game {

const Rect button1 = {300, 1 * BUTTON_SIZE_FULL, 200, BUTTON_SIZE_FULL};
const Rect button2 = {300, 2 * BUTTON_SIZE_FULL, 200, BUTTON_SIZE_FULL};
const Rect rect = {300, 11 * BUTTON_SIZE_FULL, 200, BUTTON_SIZE_FULL};

void SettingsScene::init() {
    Settings* settings = Data::getSettings();

    Gui::renderText(textMenu, "Back to menu");
    if (settings->music) {
        Gui::renderText(textMusic, "Music: On");
    } else {
        Gui::renderText(textMusic, "Music: Off");
    }

    if (settings->sound) {
        Gui::renderText(textSound, "Sound: On");
    } else {
        Gui::renderText(textSound, "Sound: Off");
    }

    Gui::renderText(textVersion, VERSION);
}

void SettingsScene::tick() {
}

void SettingsScene::draw() {
    Settings* settings = Data::getSettings();

    Gui::drawButtonDouble(button1.x, button1.y, settings->music ? 0 : 4);
    Gui::drawTextureCentered(textMusic, button1);
    Gui::drawButtonDouble(button2.x, button2.y, settings->sound ? 0 : 4);
    Gui::drawTextureCentered(textSound, button2);
    Gui::drawButtonDouble(rect.x, rect.y, 0);
    Gui::drawTextureCentered(textMenu, rect);
    Gui::drawTexture(textVersion, 0, 0);
}

void SettingsScene::event(SDL_Event* event) {
    Scene::event(event);

    if (event->type != SDL_MOUSEBUTTONUP || event->button.button != 1) {
        return;
    }

    if (isClick(rect)) {
        Audio::playEffect(0);
        Game::setCurrentScene(new MenuScene());
    } else if (isClick(button1)) {
        Audio::playEffect(0);
        Data::getSettings()->music ^= true;
        Data::saveSettings();
        Audio::playMusic(Data::getSettings()->music);
        init();
    } else if (isClick(button2)) {
        Audio::playEffect(0);
        Data::getSettings()->sound ^= true;
        Data::saveSettings();
        Audio::playMusic(Data::getSettings()->music);
        init();
    }
}

} /* namespace game */
