/*
 * LevelEditScene.cpp
 *
 *  Created on: 21.09.2014
 *      Author: user
 */

#include "Audio.h"
#include "Constants.h"
#include "Data.h"
#include "Game.h"
#include "Gui.h"
#include "Level.h"
#include "LevelEditScene.h"
#include "LevelTestScene.h"

#include <SDL.h>

namespace game {

const Rect SCROLL_BUTTON_UP = {0, 0, BUTTON_SIZE_FULL, BUTTON_SIZE_HALF};
const Rect SCROLL_BUTTON_DN = {0, 575, BUTTON_SIZE_FULL, BUTTON_SIZE_HALF};

LevelEditScene::LevelEditScene(const unsigned& scenarioId, const unsigned& levelId) :
        LevelScene(scenarioId, levelId), partHeld(Part::INVALID), scrollShop(0), animationCycle(0), textObjectiveHead(), textObjectiveBody(), textReset(), textMenu(), textStart() {
}

LevelEditScene::~LevelEditScene() {
}

void LevelEditScene::init() {
    Gui::renderText(textObjectiveHead, "Your objective:");
    Gui::renderText(textObjectiveBody, currentLevel->objective.c_str(), 180);
    Gui::renderText(textReset, "Reset");
    Gui::renderText(textMenu, "Menu");
    Gui::renderText(textStart, "Start!");
}

void LevelEditScene::tick() {
    static int animationTicks = 0;
    if (++animationTicks > 5) {
        animationCycle = (animationCycle + 1) % 4;
        animationTicks = 0;
    }
}

void LevelEditScene::draw() {
    // TODO level ist nicht ordentlich zentriert

    /* right buttons */
    Gui::drawButtonDouble(600, 0, 5);
    for (int i = 1; i < 7; ++i) {
        Gui::drawButtonDouble(600, BUTTON_SIZE_FULL * i, 7);
    }
    Gui::drawButtonDouble(600, 7 * BUTTON_SIZE_FULL, 6);
    if (currentLevel->tiles.empty()) {
        Gui::drawButtonDouble(600, 8 * BUTTON_SIZE_FULL, 4);
    } else {
        Gui::drawButtonDouble(600, 8 * BUTTON_SIZE_FULL, 0);
    }
    Gui::drawButtonDouble(600, 9 * BUTTON_SIZE_FULL, 0);
    Gui::drawButtonDouble(600, 10 * BUTTON_SIZE_FULL, 1);
    Gui::drawButtonDouble(600, 11 * BUTTON_SIZE_FULL, 2);

    Gui::drawTexture(textObjectiveHead, 610, 10);
    Gui::drawTexture(textObjectiveBody, 610, 50);
    Gui::drawTextureCentered(textReset, BUTTON_RIGHT1);
    Gui::drawTextureCentered(textMenu, BUTTON_RIGHT2);
    Gui::drawTextureCentered(textStart, BUTTON_RIGHT3);

    /* playing field */
    Gui::drawLevel(currentLevel, animationCycle);

    /* shop buttons */
    if (currentLevel->parts.size() > 12) {
        int idUp = (scrollShop > 0) ? 7 : 2;
        int idDn = (scrollShop < currentLevel->parts.size() - 11) ? 9 : 4;

        Gui::drawButtonHalf(SCROLL_BUTTON_UP.x, SCROLL_BUTTON_UP.y, idUp);
        Gui::drawButtonHalf(SCROLL_BUTTON_DN.x, SCROLL_BUTTON_DN.y, idDn);

        for (size_t i = 0; i < 11; ++i) {
            Gui::drawButtonFull(0, BUTTON_SIZE_HALF + BUTTON_SIZE_FULL * i, 4);
            if (partHeld.partId != currentLevel->parts[i + scrollShop].partId) {
                Gui::drawPart(5, 5 + BUTTON_SIZE_HALF + BUTTON_SIZE_FULL * i, animationCycle, currentLevel->parts[i + scrollShop].partId, currentLevel->parts[i + scrollShop].rotation);
            }
        }

    } else {
        for (size_t i = 0; i < currentLevel->parts.size(); ++i) {
            Gui::drawButtonFull(0, BUTTON_SIZE_FULL * i, 4);
            if (partHeld.partId != currentLevel->parts[i].partId) {
                Gui::drawPart(5, 5 + BUTTON_SIZE_FULL * i, animationCycle, currentLevel->parts[i].partId, currentLevel->parts[i].rotation);
            }
        }
    }

    /* mouse */
    if (!!partHeld) {
        Gui::drawPart(mouse.x - BUTTON_SIZE_HALF, mouse.y - BUTTON_SIZE_HALF, animationCycle, partHeld.partId, partHeld.rotation);
    }
}

void LevelEditScene::event(SDL_Event* event) {
    Scene::event(event);

    const Point field = getFieldFromMouse();
    const Part part = getShopPartFromMouse();

    switch (event->type) {
    case SDL_KEYDOWN:
        if (!partHeld) {
            return;
        }

        switch (event->key.keysym.scancode) {
        case SDL_SCANCODE_DOWN:
        case SDL_SCANCODE_S:
            partHeld.rotation = 0;
            break;

        case SDL_SCANCODE_LEFT:
        case SDL_SCANCODE_A:
            partHeld.rotation = 1;
            break;

        case SDL_SCANCODE_UP:
        case SDL_SCANCODE_W:
            partHeld.rotation = 2;
            break;

        case SDL_SCANCODE_RIGHT:
        case SDL_SCANCODE_D:
            partHeld.rotation = 3;
            break;

        default:
            break;
        }
        return;

    case SDL_MOUSEWHEEL:
        if (!!partHeld) {
            Audio::playEffect(0);
            partHeld.rotation = (partHeld.rotation + 4 + event->wheel.y) % 4;
            return;
        }

        if (mouse.x > BUTTON_SIZE_FULL || currentLevel->parts.size() < 12) {
            /* shop not big enough to scroll or mouse not over shop */
            return;
        }

        if (event->wheel.y > 0 && scrollShop > 0) {
            Audio::playEffect(0);
            scrollShop -= 1;
        }

        if (event->wheel.y < 0 && scrollShop < currentLevel->parts.size() - 11) {
            Audio::playEffect(0);
            scrollShop += 1;
        }
        return;

    case SDL_MOUSEBUTTONDOWN:
        if (event->button.button != 3 || !partHeld) {
            return;
        }

        Audio::playEffect(0);
        partHeld.rotation = (partHeld.rotation + 1) % 4;
        return;

    case SDL_MOUSEBUTTONUP:
        if (event->button.button != 1) {
            /* not left mouse button */
            return;
        }

        /* right button pressed? */
        if (isClick(BUTTON_RIGHT1)) {
            /* reset button */
            if (currentLevel->tiles.empty()) {
                Audio::playEffect(1);
            } else {
                dynamicDataClear();
                Audio::playEffect(0);
            }
            return;
        } else if (isClick(BUTTON_RIGHT2)) {
            /* menu button */
            Audio::playEffect(0);
            goMenu();
            return;
        } else if (isClick(BUTTON_RIGHT3)) {
            /* start button */
            Audio::playEffect(0);
            goTest();
            return;
        }

        /* shop scroll button pressed? */
        if (currentLevel->parts.size() > 12) {
            if (isClick(SCROLL_BUTTON_UP)) {
                if (scrollShop > 0) {
                    Audio::playEffect(0);
                    scrollShop -= 1;
                } else {
                    Audio::playEffect(1);
                }
                return;
            }
            if (isClick(SCROLL_BUTTON_DN)) {
                if (scrollShop < currentLevel->parts.size() - 11) {
                    Audio::playEffect(0);
                    scrollShop += 1;
                } else {
                    Audio::playEffect(1);
                }
                return;
            }
        }

        /* shop button pressed? */
        if (!!part) {
            if (partHeld.partId == part.partId) {
                Audio::playEffect(1);
                partHeld = Part::INVALID;
            } else {
                Audio::playEffect(0);
                partHeld = part;
            }
            return;
        }

        /* field pressed? */
        if (field.x >= 0 && field.y >= 0 && (unsigned) field.x < currentLevel->size && (unsigned) field.y < currentLevel->size) {
            if (!partHeld) {
                partHeld = currentLevel->delPart(field.x, field.y);
                if (!!partHeld) {
                    Audio::playEffect(0);
                }
            } else {
                Audio::playEffect(1);
                currentLevel->setPart(field.x, field.y, partHeld);
                if (!key[SDL_SCANCODE_LSHIFT] && !key[SDL_SCANCODE_RSHIFT]) {
                    partHeld = Part::INVALID;
                }
            }
            return;
        }

        if (!!partHeld) {
            Audio::playEffect(1);
            partHeld = Part::INVALID;
        }

        return;
    }
}

Part LevelEditScene::getShopPartFromMouse() {
    if (mouseUp.x > BUTTON_SIZE_FULL) {
        return Part::INVALID;
    }

    if (currentLevel->parts.size() > 12 && !isClick(SCROLL_BUTTON_DN) && !isClick(SCROLL_BUTTON_UP)) {
        unsigned yUp = (mouseUp.y - BUTTON_SIZE_HALF) / BUTTON_SIZE_FULL;
        unsigned yDn = (mouseDown.y - BUTTON_SIZE_HALF) / BUTTON_SIZE_FULL;
        if (yUp == yDn) {
            return currentLevel->parts[yUp + scrollShop];
        }
    } else {
        unsigned yUp = mouseUp.y / BUTTON_SIZE_FULL;
        unsigned yDn = mouseDown.y / BUTTON_SIZE_FULL;
        if (yUp == yDn && yUp < currentLevel->parts.size()) {
            return currentLevel->parts[yUp];
        }
    }
    return Part::INVALID;
}

Point LevelEditScene::getFieldFromMouse() {
    const unsigned offset = (540 - (1 + PART_SIZE * currentLevel->size)) / 2;
    Point point;
    point.x = (mouse.x - offset - 60) / PART_SIZE;
    point.y = (mouse.y - offset - 10) / PART_SIZE;
    return point;
}

} /* namespace game */
