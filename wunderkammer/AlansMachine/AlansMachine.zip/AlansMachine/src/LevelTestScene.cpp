#include "Audio.h"
#include "Data.h"
#include "Game.h"
#include "Gui.h"
#include "Level.h"
#include "LevelEditScene.h"
#include "LevelTestScene.h"
#include "LevelSuccessScene.h"

#include <SDL.h>

using namespace std;

namespace game {

#define SPECIAL_ANIMATION_SOURCE 1
#define SPECIAL_ANIMATION_SINK 2
#define SPECIAL_ANIMATION_DESTROY 3

static const Rect FOOTER = {0, 550, 600, BUTTON_SIZE_FULL};

LevelTestScene::LevelTestScene(const unsigned& scenarioId, const unsigned& levelId) :
        LevelScene(scenarioId, levelId), animationCycle(0), specialAnimation(0), specialAnimationCycle(0), physicsCycle(0), currentSpeed(4), currentTestStatus(), textBand(), textBack(), textMenu(), textFaster(), textSlower(), textPaused() {
    currentTestStatus.testId = -1;
    nextTest();
}

LevelTestScene::~LevelTestScene() {
}

bool LevelTestScene::nextTest() {
    currentTestStatus.testId += 1;
    if (currentTestStatus.testId >= currentLevel->tests.size()) {
        return false;
    }

    currentLevel->tests[currentTestStatus.testId].steps = 0;
    currentTestStatus.position.x = 0;
    currentTestStatus.position.y = currentLevel->size / 2;
    currentTestStatus.direction = DIRECTION_RIGHT;
    currentTestStatus.band = currentLevel->tests[currentTestStatus.testId].input;
    currentTestStatus.status = 0;

    if (currentTestStatus.band == "Z") {
        currentTestStatus.band = "";
    }

    specialAnimation = SPECIAL_ANIMATION_SOURCE;
    specialAnimationCycle = 0;

    return true;
}

unsigned LevelTestScene::ticksPerPhysicsStep() {
    switch (currentSpeed) {
    case 0:
        return 0;
    case 1:
        return 12;
    case 2:
        return 25;
    case 3:
        return 50;
    case 4:
        return 100;
    case 5:
        return 200;
    case 6:
        return 500;
    case 7:
        return 1000;
    case 8:
        return 2000;
    case 9:
        return 4000;
    default:
        return 0;
    }
}

void LevelTestScene::init() {
    Gui::renderText(textBand, "Tape:");
    Gui::renderText(textBack, "Back");
    Gui::renderText(textMenu, "Menu");
    Gui::renderText(textFaster, "Faster");
    Gui::renderText(textSlower, "Slower");
    Gui::renderText(textPaused, "-- Paused --");
}

void LevelTestScene::tick() {
    static unsigned animationTicks = 0;

    if (++animationTicks > 5) {
        animationCycle = (animationCycle + 1) % 4;
        animationTicks = 0;
        specialAnimationCycle += 1;
    }

    if (specialAnimation) {
        return;
    }

    if (currentTestStatus.status) {
        if (currentTestStatus.isCorrect(currentLevel->tests[currentTestStatus.testId])) {
            if (!nextTest()) {
                currentLevel->solved = true;
                goSuccess();
            }
        } else {
            goFailure(currentTestStatus);
        }
        return;
    }

    physicsCycle += ticksPerPhysicsStep();

    if (physicsCycle <= PART_SIZE * 100) {
        return;
    }

    physicsCycle = 0;

    currentLevel->tests[currentTestStatus.testId].steps += 1;

    currentTestStatus.move();

    /* hit the sink */
    if (currentTestStatus.position.x == (signed) currentLevel->size - 1 && currentTestStatus.position.y == (signed) currentLevel->size / 2) {
        currentTestStatus.status = 1;
        specialAnimation = SPECIAL_ANIMATION_SINK;
        specialAnimationCycle = 0;
        return;
    }

    Part part = currentLevel->getPart(currentTestStatus.position.x, currentTestStatus.position.y);
    if (!part) {
        currentTestStatus.status = 2;
        specialAnimation = SPECIAL_ANIMATION_DESTROY;
        specialAnimationCycle = 0;
        return;
    }

    currentTestStatus.execute(part);
}

void LevelTestScene::drawTestObject(int animation) {
    const int offset = (540 - (1 + PART_SIZE * currentLevel->size)) / 2;
    Point position = {offset + 60 + PART_SIZE * currentTestStatus.position.x, offset + 10 + PART_SIZE * currentTestStatus.position.y};

    switch (currentTestStatus.direction) {
    case 3:
        position.x -= physicsCycle / 100;
        break;

    case 2:
        position.y += physicsCycle / 100;
        break;

    case 1:
        position.x += physicsCycle / 100;
        break;

    case 0:
        position.y -= physicsCycle / 100;
        break;

    default:
        break;
    }

    Gui::drawObject(position.x, position.y, 0, animation);
}

bool LevelTestScene::drawSpecial() {
    if (!specialAnimation) {
        return false;
    }

    int animId = 0;
    switch (specialAnimationCycle) {
    case 0:
    case 6:
        animId = 0;
        break;

    case 1:
    case 5:
        animId = 1;
        break;

    case 2:
    case 4:
        animId = 2;
        break;

    case 3:
        animId = 3;
        break;

    default:
        specialAnimation = 0;
        return false;
    }

    if (specialAnimation == SPECIAL_ANIMATION_SOURCE) {
        Gui::drawLevel(currentLevel, animationCycle, animId, 0);
        if (specialAnimationCycle > 3) {
            drawTestObject(0);
        }
    } else if (specialAnimation == SPECIAL_ANIMATION_SINK) {
        Gui::drawLevel(currentLevel, animationCycle, 0, animId);
        if (specialAnimationCycle < 4) {
            drawTestObject(0);
        }
    } else if (specialAnimation == SPECIAL_ANIMATION_DESTROY) {
        Gui::drawLevel(currentLevel, animationCycle, 0, 0);
        drawTestObject(specialAnimationCycle);
    }

    return true;
}

void LevelTestScene::draw() {
    if(currentSpeed < 0) {
        Gui::drawTextureCentered(textPaused, FOOTER);
    }

    Gui::drawButtonDouble(600, 0, 5);
    for (int i = 1; i < 7; ++i) {
        Gui::drawButtonDouble(600, BUTTON_SIZE_FULL * i, 7);
    }
    Gui::drawButtonDouble(600, 7 * BUTTON_SIZE_FULL, 6);
    if (currentSpeed >= 0 && currentSpeed < 9) {
        Gui::drawButtonDouble(600, 8 * BUTTON_SIZE_FULL, 0);
    } else {
        Gui::drawButtonDouble(600, 8 * BUTTON_SIZE_FULL, 4);
    }
    if (currentSpeed > 0) {
        Gui::drawButtonDouble(600, 9 * BUTTON_SIZE_FULL, 0);
    } else {
        Gui::drawButtonDouble(600, 9 * BUTTON_SIZE_FULL, 4);
    }
    Gui::drawButtonDouble(600, 10 * BUTTON_SIZE_FULL, 1);
    Gui::drawButtonDouble(600, 11 * BUTTON_SIZE_FULL, 2);

    Gui::drawTexture(textBand, 610, 10);
    Gui::drawTextureCentered(textBack, BUTTON_RIGHT3);
    Gui::drawTextureCentered(textFaster, BUTTON_RIGHT1);
    Gui::drawTextureCentered(textSlower, BUTTON_RIGHT2);

    if (currentTestStatus.band.empty()) {
        Gui::drawBand(625, 50, 0);
    }

    Gui::drawBand(625, 50, currentTestStatus.band.c_str());

    if (drawSpecial()) {
        return;
    }
    // TODO richtungsanzeige in LevelTestScene
    // TODO pause knopf in LevelTestScene
    // TODO test mit eigenem input
    // TODO tests verstecken wie in manufactoria?
    // TODO test mit spezieller nummer nochmal machen lassen?
    // TODO zurückspulen?
    // TODO BenWiederhake: (3) Intuitiv will ich Bauteil auch durch "drag" aufsammeln
    Gui::drawLevel(currentLevel, animationCycle, 0, 0);

    if (!currentTestStatus.status) {
        drawTestObject(0);
    }
}

void LevelTestScene::event(SDL_Event* event) {
    Scene::event(event);

    switch(event->type) {
    case SDL_MOUSEBUTTONUP:
        if (event->button.button != 1) {
            return;
        }

        if (isClick(BUTTON_RIGHT1)) {
            if (currentSpeed >= 0 && currentSpeed < 9) {
                Audio::playEffect(0);
                currentSpeed += 1;
            } else {
                Audio::playEffect(1);
            }
            return;
        } else if (isClick(BUTTON_RIGHT2)) {
            if (currentSpeed > 0) {
                Audio::playEffect(0);
                currentSpeed -= 1;
            } else {
                Audio::playEffect(1);
            }
            return;
        } else if (isClick(BUTTON_RIGHT3)) {
            Audio::playEffect(0);
            goEdit();
            return;
        }

        currentSpeed = -currentSpeed;
        break;

    case SDL_MOUSEWHEEL:
        if(currentSpeed >= 0 && currentSpeed < 9 && event->wheel.y > 0) {
            Audio::playEffect(0);
            currentSpeed += 1;
            return;
        }

        if(currentSpeed > 0 && event->wheel.y < 0) {
            Audio::playEffect(0);
            currentSpeed -= 1;
            return;
        }
    }
}

} /* namespace game */
