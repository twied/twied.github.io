/*
 * Scenario.h
 *
 *  Created on: 22.09.2014
 *      Author: user
 */

#ifndef SCENARIO_H_
#define SCENARIO_H_

#include <string>
#include <vector>

namespace game {

class Level;

class Scenario {
public:
    Scenario();
    ~Scenario();

    std::string id;
    std::vector<Level *> levelList;
};

} /* namespace game */

#endif /* SCENARIO_H_ */
