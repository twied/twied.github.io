/*
 * Constants.h
 *
 *  Created on: 21.09.2014
 *      Author: user
 */

#ifndef CONSTANTS_H_
#define CONSTANTS_H_

#include "SDL_ttf.h"

typedef struct SDL_Rect SDL_Rect;
typedef struct SDL_Window SDL_Window;
typedef struct SDL_Renderer SDL_Renderer;
typedef struct SDL_Texture SDL_Texture;

namespace game {

#define VERSION "v0.2"

/** Width of the screen in px. */
#define SCREEN_WIDTH 800

/** Height of the screen in px. */
#define SCREEN_HEIGHT 600

/** Window title. */
#define SCREEN_TITLE "Alan's Machine"

/** Milliseconds per physics tick. */
#define MILLISECONDS_PER_TICK (1000 / 50)

/** Milliseconds per status report. */
#define MILLISECONDS_PER_STAT (5000)

/** Size of a tile in px. */
#define PART_SIZE 40

/** Size of a full button in px. */
#define BUTTON_SIZE_FULL 50

/** Size of a half button in px. */
#define BUTTON_SIZE_HALF 25

/** Size of a double button in px. */
#define BUTTON_SIZE_DOUBLE 200

#define MENU_MAX_Y 10

struct Point {
    int x;
    int y;
};

struct Rect {
    int x;
    int y;
    int w;
    int h;

    bool contains(const Point& point) const;
    bool contains(const int& x, const int& y) const;
    Point center() const;
};

#define PATH_SEPARATOR "/"

#define PATH_SAVE "save/"

#define PATH_LEVEL "res/level/"

#define PATH_LIST "/list.txt"

#define PATH_SETTINGS (PATH_SAVE "settings.txt")

} /* namespace game */

#endif /* CONSTANTS_H_ */
