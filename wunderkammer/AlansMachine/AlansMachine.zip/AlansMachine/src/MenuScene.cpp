/*
 * MenuScene.cpp
 *
 *  Created on: 20.09.2014
 *      Author: user
 */

#include "Audio.h"
#include "Constants.h"
#include "Data.h"
#include "Game.h"
#include "Gui.h"
#include "Level.h"
#include "LevelEditScene.h"
#include "MenuScene.h"
#include "Scenario.h"
#include "SettingsScene.h"

#include <SDL.h>

#include <map>

using namespace std;

namespace game {

static const Rect BUTTON_SCROLL_UP = {275, 0, BUTTON_SIZE_FULL, BUTTON_SIZE_HALF};
static const Rect BUTTON_SCROLL_DN = {275, 575, BUTTON_SIZE_FULL, BUTTON_SIZE_HALF};
static const Rect BUTTON_OPTIONS = {600, 10 * BUTTON_SIZE_FULL, 200, BUTTON_SIZE_FULL};
static const Rect BUTTON_EXIT = {600, 11 * BUTTON_SIZE_FULL, 200, BUTTON_SIZE_FULL};
static const Rect VISIBLE_MAP_AREA = {BUTTON_SIZE_HALF, BUTTON_SIZE_HALF, 11 * BUTTON_SIZE_FULL, 11 * BUTTON_SIZE_FULL};

MenuScene::MenuScene(unsigned currentScenario) :
        scrollOffset(0), currentScenario(currentScenario), currentMaxLevelY(0), textOptions(), textExit(), textDescriptionHead(), textDescriptionBody(), descriptionRect(NULL) {
    Scenario* scenario = Data::getScenario(currentScenario);

    for (unsigned i = 0; i < scenario->levelList.size(); ++i) {
        Level *level = Data::getLevel(currentScenario, i);
        if (isLevelVisible(level) && level->menuPosition.y > (signed) currentMaxLevelY) {
            currentMaxLevelY = level->menuPosition.y;
        }
    }
}

MenuScene::~MenuScene() {
}

bool MenuScene::isLevelVisible(const Level* level) {
    if (level->dependancies.size() == 0 || level->solved) {
        return true;
    }

    bool ok = false;
    for (size_t i = 0; i < level->dependancies.size(); ++i) {
        ok |= Data::getLevel(currentScenario, level->dependancies[i])->solved;
    }
    return ok;
}

bool MenuScene::isLevelPlayable(const Level* level) {
    if (level->dependancies.size() == 0 || level->solved) {
        return true;
    }

    bool ok = true;
    for (size_t i = 0; i < level->dependancies.size(); ++i) {
        ok &= Data::getLevel(currentScenario, level->dependancies[i])->solved;
    }
    return ok;
}

bool MenuScene::renderDescription(const Level* level, const Rect* rect, const string& head, const string& body) {
    if (!rect->contains(mouse) || (level && !isLevelVisible(level))) {
        return false;
    }

    if (rect != descriptionRect) {
        Gui::renderText(textDescriptionHead, head.c_str(), 180);
        Gui::renderText(textDescriptionBody, body.c_str(), 180);
        descriptionRect = rect;
    }
    return true;
}

Rect MenuScene::getLevelPosition(const Level* level) {
    Rect rect;
    rect.x = BUTTON_SIZE_HALF + BUTTON_SIZE_FULL * level->menuPosition.x;
    rect.y = BUTTON_SIZE_HALF + BUTTON_SIZE_FULL * (level->menuPosition.y - scrollOffset);
    rect.w = BUTTON_SIZE_FULL;
    rect.h = BUTTON_SIZE_FULL;
    return rect;
}

void MenuScene::init() {
    Gui::renderText(textOptions, "Options");
    Gui::renderText(textExit, "Exit");
    Gui::renderText(textDescriptionHead, " ");
    Gui::renderText(textDescriptionBody, " ");
}

void MenuScene::tick() {
}

void MenuScene::draw() {
    /* scroll buttons */
    if (currentMaxLevelY > MENU_MAX_Y) {
        if (scrollOffset > 0) {
            Gui::drawButtonHalf(BUTTON_SCROLL_UP.x, BUTTON_SCROLL_UP.y, 7);
        } else {
            Gui::drawButtonHalf(BUTTON_SCROLL_UP.x, BUTTON_SCROLL_UP.y, 2);
        }

        if (scrollOffset < currentMaxLevelY - MENU_MAX_Y) {
            Gui::drawButtonHalf(BUTTON_SCROLL_DN.x, BUTTON_SCROLL_DN.y, 9);
        } else {
            Gui::drawButtonHalf(BUTTON_SCROLL_DN.x, BUTTON_SCROLL_DN.y, 4);
        }
    }

    /* info field on the right side */
    Gui::drawButtonDouble(600, BUTTON_SIZE_FULL * 0, 5);
    for (int i = 1; i < 8; ++i) {
        Gui::drawButtonDouble(600, BUTTON_SIZE_FULL * i, 7);
    }
    Gui::drawButtonDouble(600, BUTTON_SIZE_FULL * 8, 6);
    Gui::drawTexture(textDescriptionHead, 610, 10);
    Gui::drawTexture(textDescriptionBody, 610, 50);

    /* options & exit buttons */
    Gui::drawButtonDouble(BUTTON_OPTIONS.x, BUTTON_OPTIONS.y, 0);
    Gui::drawButtonDouble(BUTTON_EXIT.x, BUTTON_EXIT.y, 0);
    Gui::drawTextureCentered(textOptions, BUTTON_OPTIONS);
    Gui::drawTextureCentered(textExit, BUTTON_EXIT);

    Gui::setClipRect((SDL_Rect*) &VISIBLE_MAP_AREA);
    const vector<Level*>& levelList = Data::getScenario(currentScenario)->levelList;
    /** connections */
    for (unsigned i = 0; i < levelList.size(); ++i) {
        const Level* level = levelList[i];
        if (!isLevelVisible(level)) {
            continue;
        }
        for (unsigned j = 0; j < level->dependancies.size(); ++j) {
            if (!isLevelVisible(levelList[level->dependancies[j]])) {
                continue;
            }

            const Point a = getLevelPosition(level).center();
            const Point b = getLevelPosition(levelList[level->dependancies[j]]).center();
            Gui::drawLine(a.x, a.y, b.x, b.y);
        }
    }
    /** level icons */
    for (unsigned i = 0; i < levelList.size(); ++i) {
        const Level* level = levelList[i];
        if (!isLevelVisible(level)) {
            continue;
        }

        const Rect rect = getLevelPosition(level);
        if (level->solved) {
            Gui::drawButtonFull(rect.x, rect.y, 0);
        } else if (isLevelPlayable(level)) {
            Gui::drawButtonFull(rect.x, rect.y, 4);
        } else {
            Gui::drawButtonFull(rect.x, rect.y, 7);
        }
    }
    Gui::setClipRect(NULL);
}

void MenuScene::event(SDL_Event* event) {
    Scene::event(event);

    bool hover = false;
    const vector<Level*>& levelList = Data::getScenario(currentScenario)->levelList;

    switch (event->type) {
    case SDL_MOUSEBUTTONUP:
        if (event->button.button != 1) {
            return;
        }

        if (isClick(BUTTON_SCROLL_UP)) {
            if (scrollOffset > 0) {
                Audio::playEffect(0);
                scrollOffset -= 1;
            } else {
                Audio::playEffect(1);
            }
            return;
        }

        if (isClick(BUTTON_SCROLL_DN)) {
            if (scrollOffset < currentMaxLevelY - MENU_MAX_Y) {
                Audio::playEffect(0);
                scrollOffset += 1;
            } else {
                Audio::playEffect(1);
            }
            return;
        }

        if (isClick(BUTTON_OPTIONS)) {
            Audio::playEffect(0);
            Game::setCurrentScene(new SettingsScene());
            return;
        }

        if (isClick(BUTTON_EXIT)) {
            Audio::playEffect(0);
            Game::quit();
            return;
        }

        for (size_t i = 0; i < levelList.size(); ++i) {
            const Level* level = levelList[i];
            if (isClick(getLevelPosition(level))) {
                if (isLevelPlayable(level)) {
                    Audio::playEffect(0);
                    Game::setCurrentScene(new LevelEditScene(currentScenario, i));
                } else {
                    Audio::playEffect(1);
                }
                return;
            }
        }
        break;

    case SDL_MOUSEMOTION:
        hover |= renderDescription(NULL, &BUTTON_SCROLL_UP, "Scroll up", "");
        hover |= renderDescription(NULL, &BUTTON_SCROLL_DN, "Scroll down", "");
        hover |= renderDescription(NULL, &BUTTON_OPTIONS, "Options", "");
        hover |= renderDescription(NULL, &BUTTON_EXIT, "Exit", "");

        for (size_t i = 0; i < levelList.size(); ++i) {
            const Level* level = levelList[i];
            Rect rect = getLevelPosition(level);
            hover |= renderDescription(level, &rect, level->name, level->description);
        }

        if (!hover && !!descriptionRect) {
            descriptionRect = NULL;
            Gui::renderText(textDescriptionHead, " ");
            Gui::renderText(textDescriptionBody, " ");
        }
        break;

    case SDL_MOUSEWHEEL:
        if (currentMaxLevelY <= MENU_MAX_Y) {
            return;
        }

        if (event->wheel.y < 0) {
            if (scrollOffset < currentMaxLevelY - MENU_MAX_Y) {
                Audio::playEffect(0);
                scrollOffset += 1;
            }
            return;
        }

        if (event->wheel.y > 0) {
            if (scrollOffset > 0) {
                Audio::playEffect(0);
                scrollOffset -= 1;
            }
            return;
        }
    }
}

} /* namespace game */
