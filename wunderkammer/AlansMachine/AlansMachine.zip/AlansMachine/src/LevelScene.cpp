/*
 * LevelScene.cpp
 *
 *  Created on: 21.09.2014
 *      Author: user
 */

#include "Constants.h"
#include "Data.h"
#include "Game.h"
#include "Level.h"
#include "LevelScene.h"
#include "LevelEditScene.h"
#include "LevelFailureScene.h"
#include "LevelSuccessScene.h"
#include "LevelTestScene.h"
#include "MenuScene.h"

#include <map>

using namespace std;

namespace game {

const Rect HEADER_AREA = {0, 0, SCREEN_WIDTH, BUTTON_SIZE_FULL};
const Rect BUTTON_RIGHT1 = {600, 400, 200, 50};
const Rect BUTTON_RIGHT2 = {600, 450, 200, 50};
const Rect BUTTON_RIGHT3 = {600, 500, 200, 100};

LevelScene::LevelScene(const unsigned& scenarioId, const unsigned& levelId) :
        scenarioId(scenarioId), levelId(levelId) {
    currentLevel = Data::getLevel(scenarioId, levelId);
    Data::loadLevelDynamicData(scenarioId, levelId);
}

LevelScene::~LevelScene() {
}

void LevelScene::goEdit() {
    Game::setCurrentScene(new LevelEditScene(scenarioId, levelId));
}

void LevelScene::goTest() {
    Data::saveLevelDynamicData(scenarioId, levelId);
    Game::setCurrentScene(new LevelTestScene(scenarioId, levelId));
}

void LevelScene::goSuccess() {
    Data::saveLevelDynamicData(scenarioId, levelId);
    Game::setCurrentScene(new LevelSuccessScene(scenarioId, levelId));
}

void LevelScene::goFailure(const TestStatus& testStatus) {
    Game::setCurrentScene(new LevelFailureScene(scenarioId, levelId, testStatus));
}

void LevelScene::goMenu() {
    Data::saveLevelDynamicData(scenarioId, levelId);
    Game::setCurrentScene(new MenuScene());
}

void LevelScene::dynamicDataClear() {
    Data::getLevel(scenarioId, levelId)->tiles.clear();
    Data::saveLevelDynamicData(scenarioId, levelId);
}

} /* namespace game */
