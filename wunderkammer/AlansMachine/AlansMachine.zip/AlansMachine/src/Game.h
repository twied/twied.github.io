/*
 * Game.h
 *
 *  Created on: 22.09.2014
 *      Author: user
 */

#ifndef GAME_H_
#define GAME_H_

namespace game {

class Audio;
class Data;
class Gui;
class Scene;

class Game {
public:
    Game(int argc, char *argv[]);
    operator bool();
    ~Game();

    void event();
    void tick();
    void draw();
    void stat();

    static void setCurrentScene(Scene *scene);
    static void quit();
private:
    Game(const Game& game);

    /** Current scene. */
    static Scene *currentScene;

    /** Current status. */
    static bool running;

    /** Frames since last FPS calculation. */
    unsigned frames;

    /** Ticks since last FPS calculation. */
    unsigned ticks;

    Audio *audio;
    Gui *gui;
    Data *data;
};

} /* namespace game */

#endif /* GAME_H_ */
