/*
 * Data.cpp
 *
 *  Created on: 21.09.2014
 *      Author: user
 */

#include "Constants.h"
#include "Data.h"
#include "Gui.h"
#include "Level.h"
#include "Scenario.h"

#include <fstream>
#include <sstream>
#include <string>

#include <SDL.h>

#ifdef _WIN32
#	include <windows.h>
#else
#	include <sys/stat.h>
#endif

using namespace std;

namespace game {

static void createDir(const char* dir) {
#ifdef _WIN32
    CreateDirectory(dir, NULL);
#else
    mkdir(dir, S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
#endif
}

string saveFileName(const unsigned& scenarioId, const unsigned& levelId) {
    ostringstream stream;
    stream << PATH_SAVE;
    stream << Data::getScenario(scenarioId)->id;
    stream << "_";
    stream << Data::getLevel(scenarioId, levelId)->id;
    return stream.str();
}

static void replaceNewline(string& s) {
    size_t pos = 0;
    while ((pos = s.find("\\n", pos)) != string::npos) {
        s.replace(pos, 2, "\n");
        pos += 1;
    }
}

Settings Data::settings;
std::vector<Part*> Data::partList;
std::vector<Scenario*> Data::scenarioList;

Data::Data() {
}

Data::~Data() {
    for (size_t i = 0; i < scenarioList.size(); ++i) {
        delete scenarioList[i];
    }

    for (size_t i = 0; i < partList.size(); ++i) {
        delete partList[i];
    }
}

bool Data::init() {
    /* read game settings */
    ifstream settingsStream(PATH_SETTINGS);
    if (settingsStream) {
        settingsStream >> settings.music;
        settingsStream >> settings.sound;
    }

    /* read scenario list */
    ifstream scenarioListStream(PATH_LEVEL PATH_LIST);
    if (!scenarioListStream) {
        SDL_LogError(SDL_LOG_CATEGORY_APPLICATION, "couldn't open scenario list file %s", PATH_LEVEL PATH_LIST);
        return false;
    }

    /* read scenario */
    string scenarioId;
    while (scenarioListStream >> scenarioId) {
        ifstream scenarioStream((PATH_LEVEL + scenarioId + PATH_LIST).c_str());
        if (!scenarioStream) {
            SDL_LogError(SDL_LOG_CATEGORY_APPLICATION, "can't open scenario %s", (PATH_LEVEL + scenarioId + PATH_LIST).c_str());
            return false;
        }

        Scenario* currentScenario = new Scenario();
        scenarioList.push_back(currentScenario);
        currentScenario->id = scenarioId;

        /* read scenario line */
        string scenarioLine;
        while (!getline(scenarioStream, scenarioLine).eof()) {
            stringstream scenarioLineStream(scenarioLine);

            Level* currentLevel = new Level();
            currentScenario->levelList.push_back(currentLevel);

            scenarioLineStream >> currentLevel->id;
            scenarioLineStream >> currentLevel->menuPosition.y;
            scenarioLineStream >> currentLevel->menuPosition.x;

            size_t dependancy;
            while (scenarioLineStream >> dependancy) {
                currentLevel->dependancies.push_back(dependancy - 1);
            }

            /* read level */
            ifstream levelStream((PATH_LEVEL + scenarioId + PATH_SEPARATOR + currentLevel->id).c_str());
            if (!levelStream) {
                SDL_LogError(SDL_LOG_CATEGORY_APPLICATION, "can't open level %s", (PATH_LEVEL + scenarioId + currentLevel->id).c_str());
                return false;
            }

            string partsLine;
            string dataLine;
            string testLine;

            getline(levelStream, currentLevel->name);
            getline(levelStream, currentLevel->description);
            getline(levelStream, currentLevel->objective);
            getline(levelStream, partsLine);
            getline(levelStream, dataLine);
            replaceNewline(currentLevel->description);
            replaceNewline(currentLevel->objective);

            while (getline(levelStream, testLine)) {
                stringstream testLineStream(testLine);
                Test test;
                testLineStream >> test.name;
                testLineStream >> test.accept;
                testLineStream >> test.input;
                testLineStream >> test.output;
                currentLevel->tests.push_back(test);
            }

            /* parse data line */
            stringstream dataLineStream(dataLine);
            dataLineStream >> currentLevel->size;
            dataLineStream >> currentLevel->binary;

            /* parse parts line */
            stringstream partsLineStream(partsLine);
            string part;
            while (partsLineStream >> part) {
                currentLevel->parts.push_back(Part::getPartByName(part));
            }
        }
    }

    for (size_t scenarioId = 0; scenarioId < scenarioList.size(); ++scenarioId) {
        for (size_t levelId = 0; levelId < scenarioList[scenarioId]->levelList.size(); ++levelId) {
            loadLevelDynamicData(scenarioId, levelId);
        }
    }
    return true;
}

Level* Data::getLevel(const unsigned& scenarioId, const unsigned& levelId) {
    return scenarioList[scenarioId]->levelList[levelId];
}

Scenario* Data::getScenario(const unsigned& scenarioId) {
    return scenarioList[scenarioId];
}

bool Data::loadLevelDynamicData(const unsigned& scenarioId, const unsigned& levelId) {
    ifstream stream(saveFileName(scenarioId, levelId).c_str());
    if (!stream) {
        return false;
    }

    Level *level = getLevel(scenarioId, levelId);
    stream >> level->solved;
    stream >> level->totalSteps;
    stream >> level->totalStepsBest;
    stream >> level->totalStepsWorst;
    stream >> level->totalPartsBest;

    size_t numTiles;
    stream >> numTiles;

    level->tiles.clear();
    for (size_t i = 0; i < numTiles; ++i) {
        Tile tile;
        stream >> tile.x >> tile.y >> tile.partId >> tile.rotation;
        level->tiles.push_back(tile);
    }

    return true;
}

bool Data::saveLevelDynamicData(const unsigned& scenarioId, const unsigned& levelId) {
    createDir(PATH_SAVE);
    ofstream stream(saveFileName(scenarioId, levelId).c_str());
    if (!stream) {
        SDL_LogError(SDL_LOG_CATEGORY_APPLICATION, "can't open to write %s", saveFileName(scenarioId, levelId).c_str());
        return false;
    }

    Level *level = getLevel(scenarioId, levelId);

    stream << level->solved << endl;
    stream << level->totalSteps << endl;
    stream << level->totalStepsBest << endl;
    stream << level->totalStepsWorst << endl;
    stream << level->totalPartsBest << endl;
    stream << level->tiles.size() << endl;
    for (vector<Tile>::const_iterator it = level->tiles.begin(); it != level->tiles.end(); ++it) {
        stream << it->x << " " << it->y << " " << it->partId << " " << it->rotation << endl;
    }

    return true;
}

Settings* Data::getSettings() {
    return &settings;
}

void Data::saveSettings() {
    createDir(PATH_SAVE);
    ofstream settingsStream(PATH_SETTINGS);
    if (!settingsStream) {
        SDL_LogError(SDL_LOG_CATEGORY_APPLICATION, "can't open to write %s", PATH_SETTINGS);
        return;
    }

    settingsStream << settings.music << endl;
    settingsStream << settings.sound << endl;
}

//bool Data::saveLevelStaticData(const string& id) {
//}

} /* namespace game */
