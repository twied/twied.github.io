/*
 * Texture.cpp
 *
 *  Created on: 23.09.2014
 *      Author: user
 */

#include "Texture.h"

#include <SDL.h>

namespace game {

Texture::Texture() :
        texture(NULL) {
}

Texture::~Texture() {
    del();
}

SDL_Texture* Texture::get() const {
    return texture;
}

void Texture::set(SDL_Texture* texture) {
    del();
    this->texture = texture;
}

void Texture::del() {
    if (texture) {
        SDL_DestroyTexture(texture);
    }
    texture = NULL;
}

} /* namespace game */
