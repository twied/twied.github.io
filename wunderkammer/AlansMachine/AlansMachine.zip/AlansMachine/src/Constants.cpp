/*
 * Constants.cpp
 *
 *  Created on: 21.09.2014
 *      Author: user
 */

#include "Constants.h"

namespace game {

bool Rect::contains(const Point& point) const {
    return point.x >= x && point.y >= y && point.x <= x + w && point.y <= y + h;
}

bool Rect::contains(const int& px, const int& py) const {
    return px >= x && py >= y && px <= x + w && py <= y + h;
}

Point Rect::center() const {
    const Point c = {x + w / 2, y + h / 2};
    return c;
}

} /* namespace game */
