/*
 * LevelEditScene.h
 *
 *  Created on: 21.09.2014
 *      Author: user
 */

#ifndef LEVELEDITSCENE_H_
#define LEVELEDITSCENE_H_

#include "Level.h"
#include "LevelScene.h"
#include "Texture.h"

namespace game {

class Level;
class Texture;

class LevelEditScene : public LevelScene {
public:
    LevelEditScene(const unsigned& scenarioId, const unsigned& levelId);
    virtual ~LevelEditScene();

    virtual void init();
    virtual void tick();
    virtual void draw();
    virtual void event(SDL_Event* event);
private:
    Part getShopPartFromMouse();
    Point getFieldFromMouse();

    Part partHeld;
    unsigned scrollShop;
    int animationCycle;
    Texture textObjectiveHead;
    Texture textObjectiveBody;
    Texture textReset;
    Texture textMenu;
    Texture textStart;
};

} /* namespace game */

#endif /* LEVELEDITSCENE_H_ */
