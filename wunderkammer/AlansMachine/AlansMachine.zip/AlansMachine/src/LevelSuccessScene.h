/*
 * LevelSuccessScene.h
 *
 *  Created on: 21.09.2014
 *      Author: user
 */

#ifndef LEVELSUCCESSSCENE_H_
#define LEVELSUCCESSSCENE_H_

#include "LevelScene.h"
#include "Texture.h"

namespace game {

class LevelSuccessScene : public LevelScene {
public:
    LevelSuccessScene(const unsigned& scenarioId, const unsigned& levelId);
    virtual ~LevelSuccessScene();
    virtual void init();
    virtual void tick();
    virtual void draw();
    virtual void event(SDL_Event* event);

private:
    Texture textSuccess;
    Texture textRerun;
    Texture textMenu;
    Texture textRunThis;
    Texture textRunBest;
    Texture textParts;
    Texture textObjectiveHead;
    Texture textObjectiveBody;
    Texture textPartAmount[MAX_PARTS];
    Texture textCyclesTotal[3];
    Texture textCyclesAverage[3];
    Texture textCyclesBest[3];
    Texture textCyclesWorst[3];
    Texture textPartsUsed[3];
};

} /* namespace game */

#endif /* LEVELSUCCESSSCENE_H_ */
