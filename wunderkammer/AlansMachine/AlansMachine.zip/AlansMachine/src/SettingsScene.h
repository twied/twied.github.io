/*
 * SettingsScene.h
 *
 *  Created on: 23.09.2014
 *      Author: user
 */

#ifndef SETTINGSSCENE_H_
#define SETTINGSSCENE_H_

#include "Scene.h"
#include "Texture.h"

namespace game {

class SettingsScene : public Scene {
public:
    virtual void init();
    virtual void tick();
    virtual void draw();
    virtual void event(SDL_Event* event);
private:
    Texture textSound;
    Texture textMusic;
    Texture textMenu;
    Texture textVersion;
};

} /* namespace game */

#endif /* SETTINGSSCENE_H_ */
