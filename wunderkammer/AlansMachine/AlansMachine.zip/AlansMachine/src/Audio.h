/*
 * Audio.h
 *
 *  Created on: 23.09.2014
 *      Author: user
 */

#ifndef AUDIO_H_
#define AUDIO_H_

#include "SDL_mixer.h"

namespace game {

class Audio {
public:
    Audio();
    ~Audio();

    static bool init();
    static void playEffect(int effectId);
    static void playMusic(bool enable);
private:
    static Mix_Chunk* clickGood;
    static Mix_Chunk* clickBad;
    static Mix_Music* music;
};

} /* namespace game */

#endif /* AUDIO_H_ */
