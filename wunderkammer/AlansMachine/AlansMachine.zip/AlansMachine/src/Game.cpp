/*
 * Game.cpp
 *
 *  Created on: 22.09.2014
 *      Author: user
 */

#include "Audio.h"
#include "Constants.h"
#include "Data.h"
#include "Game.h"
#include "Gui.h"
#include "MenuScene.h"
#include "Scene.h"

#include <SDL.h>

namespace game {

Scene* Game::currentScene = 0;
bool Game::running = false;

Game::Game(int argc, char *argv[]) :
        frames(0), ticks(0), gui(NULL), data(NULL) {
    gui = new Gui();
    data = new Data();
    audio = new Audio();

    if (!data->init()) {
        return;
    }

    if (!gui->init()) {
        return;
    }

    if (!audio->init()) {
        return;
    }

    setCurrentScene(new MenuScene());
    running = true;
}

Game::~Game() {
    if (currentScene) {
        delete currentScene;
    }

    delete audio;
    delete gui;
    delete data;
}

void Game::draw() {
    gui->drawBegin();
    currentScene->draw();
    gui->drawEnd();

    frames += 1;
}

void Game::event() {
    SDL_Event event;
    while (SDL_PollEvent(&event)) {
        if (event.type == SDL_QUIT) {
            running = false;
        }

        currentScene->event(&event);
    }
}

void Game::stat() {
    static Uint32 nextStat = SDL_GetTicks() + MILLISECONDS_PER_STAT;

    if (SDL_GetTicks() >= nextStat) {
        //SDL_LogInfo(SDL_LOG_CATEGORY_APPLICATION, "tps: %4i, fps: %4i\n", ticks / (MILLISECONDS_PER_STAT / 1000), frames / (MILLISECONDS_PER_STAT / 1000));
        nextStat += MILLISECONDS_PER_STAT;
        frames = 0;
        ticks = 0;
    }
}

void Game::tick() {
    static Uint32 nextTick = SDL_GetTicks() + MILLISECONDS_PER_TICK;

    while (SDL_GetTicks() >= nextTick) {
        ticks += 1;
        currentScene->tick();
        nextTick += MILLISECONDS_PER_TICK;
    }
}

Game::operator bool() {
    return running;
}

void Game::setCurrentScene(Scene *scene) {
    delete currentScene;
    currentScene = scene;
    currentScene->init();
}

void Game::quit() {
    running = false;
}

} /* namespace game */
