/*
 * Texture.h
 *
 *  Created on: 23.09.2014
 *      Author: user
 */

#ifndef TEXTURE_H_
#define TEXTURE_H_

typedef struct SDL_Texture SDL_Texture;

namespace game {

class Texture {
public:
    Texture();
    ~Texture();

    SDL_Texture* get() const;
    void set(SDL_Texture* texture);
    void del();
private:
    Texture(const Texture& other);
    Texture& operator=(const Texture& other);

    SDL_Texture* texture;
};

} /* namespace game */

#endif /* TEXTURE_H_ */
