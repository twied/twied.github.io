/*
 * Scene.h
 *
 *  Created on: 21.09.2014
 *      Author: user
 */

#ifndef SCENE_H_
#define SCENE_H_

#include "Constants.h"

union SDL_Event;

namespace game {

class Scene {
public:
    Scene();
    virtual ~Scene();

    /** Scene setup. Called before first tick() and draw(). */
    virtual void init() = 0;

    /** Single physics step. */
    virtual void tick() = 0;

    /** Draw current state. */
    virtual void draw() = 0;

    /** Handle single event. */
    virtual void event(SDL_Event* event);

    bool isClick(const Rect& rect);

    /** Current Mouse position. */
    Point mouse;

    /** Last button down position. */
    Point mouseDown;

    /** Last button up position. */
    Point mouseUp;

    /** Keyboard status. */
    bool key[512];
};

} /* namespace game */

#endif /* SCENE_H_ */
