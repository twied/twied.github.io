/*
 * Level.h
 *
 *  Created on: 21.09.2014
 *      Author: user
 */

#ifndef LEVEL_H_
#define LEVEL_H_

#include "Constants.h"

#include <string>
#include <vector>

namespace game {

#define DIRECTION_UP 0
#define DIRECTION_RIGHT 1
#define DIRECTION_DOWN 2
#define DIRECTION_LEFT 3
#define DIRECTION_NONE 4

#define MAX_PARTS 13
class Part {
public:
    static const Part INVALID;
    static const Part SOURCE;
    static const Part SINK;
    static const Part BELT;
    static const Part CROSS_L;
    static const Part CROSS_R;
    static const Part BRANCH_RB;
    static const Part BRANCH_BR;
    static const Part BRANCH_GY;
    static const Part BRANCH_YG;
    static const Part PRINTER_R;
    static const Part PRINTER_B;
    static const Part PRINTER_G;
    static const Part PRINTER_Y;

    static Part getPartByName(const std::string& name, const int& rotation = 0);
    static Part getPartById(const int& partId, const int& rotation = 0);

    std::string name;
    int partId;
    int rotation;

    ~Part();
    bool operator!() const;
    bool operator==(const Part& other) const;
    bool operator!=(const Part& other) const;
private:
    Part(const std::string& name, const int& partId, const int& rotation);
};

struct Tile {
    int x;
    int y;
    int partId;
    int rotation;

    Tile();
    Tile(const int& x, const int& y, const int& partId, const int& rotation);
    ~Tile();
};

struct Test {
    std::string name;
    std::string input;
    std::string output;
    bool accept;

    /** User data: steps for the current test to complete. */
    unsigned steps;
};

struct TestStatus {
    std::string band;
    Point position;
    int direction;
    unsigned testId;
    unsigned status; /* 0: running, 1: accept, 2: reject */

    bool isCorrect(const Test& test);
    void move();
    void execute(const Part& part);
};

struct Level {
    /** Level id. Save to use as a filename. */
    std::string id;

    /** Short name. */
    std::string name;

    /** Description in the menu. */
    std::string description;

    /** Objective in the level editor. */
    std::string objective;

    /** Dependancies on other levels. */
    std::vector<int> dependancies;

    /** Allowed parts. */
    std::vector<Part> parts;

    /** Position in the menu. */
    Point menuPosition;

    /** Size of the field. */
    unsigned size;

    /** Is this a binary level. */
    bool binary;

    /** Tests. */
    std::vector<Test> tests;

    /** User data: Has this level been solved. */
    bool solved;

    /** User data: total time units to test completion. */
    unsigned totalSteps;

    /** User data: best time to beat a test. */
    unsigned totalStepsBest;

    /** User data: worst time to beat a test. */
    unsigned totalStepsWorst;

    /** User data: least total parts used. */
    unsigned totalPartsBest;

    /** User data: Playing field. */
    std::vector<Tile> tiles;

    void setPart(const int x, const int y, const Part& part);
    Part getPart(const int x, const int y) const;
    Part delPart(const int x, const int y);
};

} /* namespace game */

#endif /* LEVEL_H_ */
