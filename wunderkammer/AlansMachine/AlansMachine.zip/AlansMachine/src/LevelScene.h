/*
 * LevelScene.h
 *
 *  Created on: 21.09.2014
 *      Author: user
 */

#ifndef LEVELSCENE_H_
#define LEVELSCENE_H_

#include "Scene.h"

#include <string>

namespace game {

extern const Rect HEADER_AREA;
extern const Rect BUTTON_DROP_PART;
extern const Rect BUTTON_RIGHT1;
extern const Rect BUTTON_RIGHT2;
extern const Rect BUTTON_RIGHT3;

class Level;

class LevelScene : public Scene {
public:
    LevelScene(const unsigned& scenarioId, const unsigned& levelId);
    virtual ~LevelScene();

    void goEdit();
    void goTest();
    void goSuccess();
    void goFailure(const TestStatus& testStatus);
    void goMenu();

    void dynamicDataLoad();
    void dynamicDataSave();
    void dynamicDataClear();

    unsigned scenarioId;
    unsigned levelId;
    Level *currentLevel;
};

} /* namespace game */

#endif /* LEVELSCENE_H_ */
