/*
 * Gui.cpp
 *
 *  Created on: 21.09.2014
 *      Author: user
 */

#include "Constants.h"
#include "Game.h"
#include "Gui.h"
#include "Level.h"
#include "Texture.h"

#include <SDL.h>
#include <SDL_image.h>
#include <SDL_ttf.h>

#include <map>

using namespace std;

namespace game {

TTF_Font *Gui::font = NULL;
SDL_Window *Gui::window = NULL;
SDL_Renderer *Gui::renderer = NULL;
SDL_Texture *Gui::buttons_half = NULL;
SDL_Texture *Gui::buttons_full = NULL;
SDL_Texture *Gui::buttons_double = NULL;
SDL_Texture *Gui::parts = NULL;
SDL_Texture *Gui::testobjects = NULL;
SDL_Texture *Gui::band = NULL;
SDL_Texture *Gui::line = NULL;

static int getBandType(char currentSymbol) {
    switch (currentSymbol) {
    case 'Z':
        return 0;
    case 'R':
        return 1;
    case 'B':
        return 2;
    case 'G':
        return 3;
    case 'Y':
        return 4;
    default:
        return 5;
    }
}

Gui::Gui() {
}

Gui::~Gui() {
    if (renderer) {
        SDL_DestroyRenderer(renderer);
    }

    if (window) {
        SDL_DestroyWindow(window);
    }

    if (buttons_half) {
        SDL_DestroyTexture(buttons_half);
    }

    if (buttons_full) {
        SDL_DestroyTexture(buttons_full);
    }

    if (buttons_double) {
        SDL_DestroyTexture(buttons_double);
    }

    if (parts) {
        SDL_DestroyTexture(parts);
    }

    if (testobjects) {
        SDL_DestroyTexture(testobjects);
    }

    if (band) {
        SDL_DestroyTexture(band);
    }

    if (line) {
        SDL_DestroyTexture(line);
    }

    if (font) {
        TTF_CloseFont(font);
    }

    TTF_Quit();
    IMG_Quit();
    SDL_Quit();
}

void Gui::drawBegin() const {
    SDL_SetRenderDrawColor(renderer, 255, 255, 255, 255);
    SDL_RenderClear(renderer);
}

void Gui::drawEnd() const {
    SDL_RenderPresent(renderer);
    SDL_Delay(1);
}

bool Gui::init() {
    if (SDL_Init(SDL_INIT_EVERYTHING)) {
        showMessageBox("SDL_Init failed", SDL_GetError());
        return false;
    }

    if (!IMG_Init(IMG_INIT_PNG)) {
        showMessageBox("IMG_Init failed", IMG_GetError());
        return false;
    }

    if (TTF_Init()) {
        showMessageBox("TTF_Init failed", TTF_GetError());
        return false;
    }

    font = TTF_OpenFont("res/Warenhaus-Standard.ttf", 20);
    if (!font) {
        showMessageBox("TTF_OpenFont failed", TTF_GetError());
        return false;
    }
    TTF_SetFontHinting(font, TTF_HINTING_LIGHT);

    window = SDL_CreateWindow(SCREEN_TITLE, SDL_WINDOWPOS_UNDEFINED, SDL_WINDOWPOS_UNDEFINED, 800, 600, 0);
    if (!window) {
        showMessageBox("SDL_CreateWindow failed", SDL_GetError());
        return false;
    }

    renderer = SDL_CreateRenderer(window, -1, 0);
    if (!renderer) {
        showMessageBox("SDL_CreateRenderer failed", SDL_GetError());
        return false;
    }

    buttons_half = IMG_LoadTexture(renderer, "res/pictures/buttons_half.png");
    if (!buttons_half) {
        showMessageBox("IMG_LoadTexture failed for buttons_half.png", IMG_GetError());
        return false;
    }

    buttons_full = IMG_LoadTexture(renderer, "res/pictures/buttons_full.png");
    if (!buttons_half) {
        showMessageBox("IMG_LoadTexture failed for buttons_full.png", IMG_GetError());
        return false;
    }

    buttons_double = IMG_LoadTexture(renderer, "res/pictures/buttons_double.png");
    if (!buttons_double) {
        showMessageBox("IMG_LoadTexture failed for buttons_double.png", IMG_GetError());
        return false;
    }

    parts = IMG_LoadTexture(renderer, "res/pictures/parts.png");
    if (!parts) {
        showMessageBox("IMG_LoadTexture failed for parts.png", IMG_GetError());
        return false;
    }

    testobjects = IMG_LoadTexture(renderer, "res/pictures/testobjects.png");
    if (!testobjects) {
        showMessageBox("IMG_LoadTexture failed for testobjects.png", IMG_GetError());
        return false;
    }

    band = IMG_LoadTexture(renderer, "res/pictures/band.png");
    if (!band) {
        showMessageBox("IMG_LoadTexture failed for band.png", IMG_GetError());
        return false;
    }

    line = IMG_LoadTexture(renderer, "res/pictures/line.png");
    if (!line) {
        showMessageBox("IMG_LoadTexture failed for line.png", IMG_GetError());
        return false;
    }

    return true;
}

int Gui::showMessageBox(const char* title, const char* message) {
    const SDL_MessageBoxButtonData buttonData[] = { {SDL_MESSAGEBOX_BUTTON_RETURNKEY_DEFAULT, 0, "OK"}};
    const SDL_MessageBoxColor colBackground = {211, 215, 207};
    const SDL_MessageBoxColor colText = {46, 52, 54};
    const SDL_MessageBoxColor colBorder = {46, 52, 54};
    const SDL_MessageBoxColor colButtonBackground = {252, 175, 62};
    const SDL_MessageBoxColor colButtonSelected = {245, 121, 0};
    const SDL_MessageBoxColorScheme colorScheme = {colBackground, colText, colBorder, colButtonBackground, colButtonSelected};
    const SDL_MessageBoxData data = {SDL_MESSAGEBOX_INFORMATION, window, title, message, SDL_arraysize(buttonData), buttonData, &colorScheme};
    int buttonId;

    SDL_LogError(SDL_LOG_CATEGORY_APPLICATION, "message: title=%s, message=%s", title, message);
    SDL_ShowMessageBox(&data, &buttonId);
    return buttonId;
}

void Gui::drawButtonHalf(int x, int y, int id) {
    SDL_Rect source = {id * BUTTON_SIZE_FULL, 0, BUTTON_SIZE_FULL, BUTTON_SIZE_HALF};
    SDL_Rect dest = {x, y, BUTTON_SIZE_FULL, BUTTON_SIZE_HALF};
    SDL_RenderCopy(renderer, buttons_half, &source, &dest);
}

void Gui::drawButtonFull(int x, int y, int id) {
    SDL_Rect source = {id * BUTTON_SIZE_FULL, 0, BUTTON_SIZE_FULL, BUTTON_SIZE_FULL};
    SDL_Rect dest = {x, y, BUTTON_SIZE_FULL, BUTTON_SIZE_FULL};
    SDL_RenderCopy(renderer, buttons_full, &source, &dest);
}

void Gui::drawButtonDouble(int x, int y, int id) {
    SDL_Rect source = {id * BUTTON_SIZE_DOUBLE, 0, BUTTON_SIZE_FULL * 4, BUTTON_SIZE_FULL};
    SDL_Rect dest = {x, y, BUTTON_SIZE_FULL * 4, BUTTON_SIZE_FULL};
    SDL_RenderCopy(renderer, buttons_double, &source, &dest);
}

void Gui::drawPart(int x, int y, int animation, int id, int rotation) {
    SDL_Rect source = {animation * PART_SIZE, id * PART_SIZE, PART_SIZE, PART_SIZE};
    SDL_Rect dest = {x, y, PART_SIZE, PART_SIZE};
    SDL_RenderCopyEx(renderer, parts, &source, &dest, 90.0 * rotation, NULL, SDL_FLIP_NONE);
}

void Gui::drawBand(int x, int y, const char* band) {
    for (unsigned i = 0; i < 8 * 5 && band[i] != '\0'; ++i) {
        Gui::drawBand(x + 30 * (i % 5), y + 40 * (i / 5), getBandType(band[i]));
    }
}

void Gui::drawBand(int x, int y, int id) {
    SDL_Rect source = {id * PART_SIZE, 0, PART_SIZE, PART_SIZE};
    SDL_Rect dest = {x, y, PART_SIZE, PART_SIZE};
    SDL_RenderCopy(renderer, band, &source, &dest);
}

void Gui::drawLevel(Level* level, int animationCycle, int sourceCycle, int sinkCycle) {
    const unsigned offset = (540 - (1 + PART_SIZE * level->size)) / 2;
    drawColor(0, 0, 0, 255);
    for (unsigned i = 0; i <= level->size; ++i) {
        SDL_RenderDrawLine(renderer,offset + 60, offset + 10 + PART_SIZE * i, offset + 60 + PART_SIZE * level->size, offset + 10 + PART_SIZE * i);
        SDL_RenderDrawLine(renderer,offset + 60 + PART_SIZE * i, offset + 10, offset + 60 + PART_SIZE * i, offset + 10 + PART_SIZE * level->size);
    }

    for (vector<Tile>::const_iterator it = level->tiles.begin(); it != level->tiles.end(); ++it) {
        drawPart(offset + 60 + PART_SIZE * it->x, offset + 10 + PART_SIZE * it->y, animationCycle, it->partId, it->rotation);
    }

    drawPart(offset + 60, offset + 10 + PART_SIZE * (level->size / 2), sourceCycle, 0);
    drawPart(offset + 60 + PART_SIZE * (level->size - 1), offset + 10 + PART_SIZE * (level->size / 2), sinkCycle, 1);
}

void Gui::drawLine(int x1, int y1, int x2, int y2) {
#if 0
    SDL_SetRenderDrawColor(renderer, 46, 52, 54, 255);
    for(int y = -1; y <= 1; ++y) {
        for(int x = -1; x <= 1; ++x) {
            SDL_RenderDrawLine(renderer, x1 + x, y1 + y, x2 + x, y2 + y);
        }
    }
    //SDL_SetRenderDrawColor(renderer, 252, 175, 62, 255);
    SDL_RenderDrawLine(renderer, x1, y1, x2, y2);
#else
    SDL_Point center = {2, 0};
    SDL_Rect dest = {x1, y1, 7, (int)sqrt(pow(x1 - x2, 2) + pow(y1 - y2, 2))};
    SDL_RenderCopyEx(renderer, line, NULL, &dest, (180 / M_PI) * atan2(y2 - y1, x2 - x1) - 90, &center, SDL_FLIP_NONE);
#endif
}

void Gui::drawColor(int r, int g, int b, int a) {
    SDL_SetRenderDrawColor(renderer, r, g, b, a);
}

void Gui::drawObject(int x, int y, int id, int animation) {
    SDL_Rect source = {0, id * PART_SIZE, PART_SIZE, PART_SIZE};
    SDL_Rect dest = {x, y, PART_SIZE, PART_SIZE};
    SDL_RenderCopyEx(renderer, testobjects, &source, &dest, 20.0 * animation, NULL, SDL_FLIP_NONE);
}

void Gui::drawTexture(const Texture& texture, int x, int y) {
    SDL_Rect dest = {x, y, 0, 0};
    SDL_QueryTexture(texture.get(), NULL, NULL, &dest.w, &dest.h);
    SDL_RenderCopy(renderer, texture.get(), NULL, &dest);
}

void Gui::drawTextureCentered(const Texture& texture, const Rect& rect) {
    int w;
    int h;
    SDL_QueryTexture(texture.get(), NULL, NULL, &w, &h);
    drawTexture(texture, rect.x + (rect.w - w) / 2, rect.y + (rect.h - h) / 2);
}

void Gui::renderText(Texture& result, const char *text, unsigned wrapLength) {
    static const SDL_Color black = {0, 0, 0, 255};
    SDL_Surface *surface = TTF_RenderText_Blended_Wrapped(font, text, black, wrapLength);

    if (!surface) {
        SDL_LogError(SDL_LOG_CATEGORY_APPLICATION, "cannot render text to surface: %s", TTF_GetError());
        result.set(NULL);
        return;
    }

    SDL_Texture *texture = SDL_CreateTextureFromSurface(renderer, surface);
    if (!surface) {
        SDL_LogError(SDL_LOG_CATEGORY_APPLICATION, "cannot render surface to texture: %s", SDL_GetError());
        SDL_FreeSurface(surface);
        result.set(NULL);
        return;
    }

    SDL_FreeSurface(surface);
    result.set(texture);
}

void Gui::setClipRect(const SDL_Rect* rect) {
    SDL_RenderSetClipRect(renderer, rect);
}

} /* namespace game */
