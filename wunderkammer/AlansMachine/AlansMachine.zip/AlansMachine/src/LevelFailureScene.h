/*
 * LevelFailureScene.h
 *
 *  Created on: 21.09.2014
 *      Author: user
 */

#ifndef LEVELFAILURESCENE_H_
#define LEVELFAILURESCENE_H_

#include "LevelScene.h"
#include "Texture.h"

namespace game {

class Level;

class LevelFailureScene : public LevelScene {
public:
    LevelFailureScene(const unsigned& scenarioId, const unsigned& levelId, const TestStatus& testStatus);
    virtual ~LevelFailureScene();
    virtual void init();
    virtual void tick();
    virtual void draw();
    virtual void event(SDL_Event* event);
private:
    TestStatus testStatus;

    Texture textFailure;
    Texture textRetry;
    Texture textMenu;
    Texture textObjectiveHead;
    Texture textObjectiveBody;
    Texture textInput;
    Texture textExpected;
    Texture textOutput;
    Texture textAcceptExpected;
    Texture textAcceptOutput;
};

} /* namespace game */

#endif /* LEVELFAILURESCENE_H_ */
